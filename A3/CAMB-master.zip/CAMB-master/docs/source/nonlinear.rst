Non-linear models
==================================

.. autoclass:: camb.nonlinear.NonLinearModel
   :members:

.. autoclass:: camb.nonlinear.Halofit
   :show-inheritance:
   :members:

.. autoclass:: camb.nonlinear.SecondOrderPK
   :show-inheritance:
   :members:

