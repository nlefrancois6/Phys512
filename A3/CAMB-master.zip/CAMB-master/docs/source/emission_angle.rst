Lensing emission angle
==================================

.. automodule:: camb.emission_angle
   :members:



