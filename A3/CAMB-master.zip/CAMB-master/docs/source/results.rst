Calculation results
==================================

.. autoclass:: camb.results.CAMBdata
   :members:
   :inherited-members:


.. autoclass:: camb.results.MatterTransferData
   :members:
   :inherited-members:

.. autoclass:: camb.results.ClTransferData
   :members:


