Initial power spectra
==================================

.. autoclass:: camb.initialpower.InitialPower
   :members:

.. autoclass:: camb.initialpower.InitialPowerLaw
   :show-inheritance:
   :members:


.. autoclass:: camb.initialpower.SplinedInitialPower
   :show-inheritance:
   :members:


